from aiogram.types import InlineKeyboardButton as IB
from aiogram.types import InlineKeyboardMarkup as IM
from libs.classes import Button, Menu, MenuButton


class chat:
    class admin:
        undo = Button("↩ Undo", "undo")


class private:
    class settings:
        settings = "Choose what you want customize"
        chats = "Chats"

        chats_menu = "Choose a chat"  # Вывод кнопок

        chat_settings = "Choose option"  # При выборе чата
        sticker_alias = "Manage a sticker aliases"
        command_alias = "Manage a text aliases"

        alias_menu = "Choose action\n" +\
                     "Click on the existing alias to edit"
        add_alias = "Add alias"

        delete_text = "🔥 Delete"
        delete_title = "⚠ Delete alias ?"
        delete_accept = "✅ Delete"
        delete_cancel = "⛔ Cancel"
