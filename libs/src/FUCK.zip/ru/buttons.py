from aiogram.types import InlineKeyboardButton as IB
from aiogram.types import InlineKeyboardMarkup as IM
from libs.classes import Button, Menu, MenuButton


class chat:
    class admin:
        undo = Button("↩ Отмена", "undo")


class private:
    class settings:
        settings = "Выбери что хочешь настроить"

        chats_menu = "Выбери чат"

        chat_settings = "Выбери что хочешь настроить"
        sticker_alias = "Сокращения к стикерам"
        command_alias = "Сокращения к тексту"

        alias_menu = "Выбери действие\n" +\
                     "Щелкните на существующие сокращение, чтобы изменить"

        add_alias = "Добавить сокращение"

        delete_text = "🔥 Удалить"
        delete_title = "⚠ Удалить сокращение ?"
        delete_accept = "✅ Удалить"
        delete_cancel = "⛔ Отмена"
